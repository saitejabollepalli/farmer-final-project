export class User{
            userId?:number;
            firstName?:string;
            lastName?:string ;
            email?:string ;
            address1?:string; 
            address2?:string ;
            city?:string;
            state?:string;
            pincode?:string;
            aadharCard?:any;
            panCard?:any;
            certificate?:any; 
            traderLicense?:any; 
            password?:string;
            verificationStatus?:string; 
            approvedBy?:string ;  
            roletype?:string;
            accountNo?:string;
            ifscCode?:string;   
            landArea?:string;
            landAddress?:string;
            landPincode?:string;
           

}