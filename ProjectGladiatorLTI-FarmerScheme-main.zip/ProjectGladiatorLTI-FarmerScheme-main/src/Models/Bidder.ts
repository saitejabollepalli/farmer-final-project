export class Bidder{
        bId1?:Number;
        cropId?:Number;
        userId?:Number;
        
        bidAmount?:Number;
        
        dateOfBid?:Number;
        bidStatus?:string;
}