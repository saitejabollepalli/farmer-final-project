export class Claim{
    claimId?:number;
    policyNo?:number;
    icompany?:string;
    insuranceName?:string;
    dateOfLoss?:Date;
    causeOfLoss?:string;
    sumInsured?:number;
    claimStatus?:string;
    
}