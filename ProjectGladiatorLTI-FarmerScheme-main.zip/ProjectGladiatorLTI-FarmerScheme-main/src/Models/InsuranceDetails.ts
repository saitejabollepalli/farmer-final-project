export class InsuranceDetails {
    insuranceCompany?:string;
    sumInsuredPerHectare?:number;
    sharePremium?:number;
    premiumAmount?:number;
    cropName?:string;
    area?:number;
    sumInsured?:number;
    cropType?:string;
    
}