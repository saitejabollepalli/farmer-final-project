export class ClaimInsurance{
    PolicyNo?:string;
    Icompany?:string
    InsuranceName?:string;
    DateOfLoss?:Date;
    CauseOfLoss?:string;
    SumInsured?:any;
}