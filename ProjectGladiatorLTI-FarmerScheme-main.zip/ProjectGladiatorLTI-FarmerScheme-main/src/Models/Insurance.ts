export class Insurance {
    cropType?:string;
    year?:string;
    cropName?:string;
    area?:number;
    season?:string;
    sumInsuredPerHectare?:any;
}