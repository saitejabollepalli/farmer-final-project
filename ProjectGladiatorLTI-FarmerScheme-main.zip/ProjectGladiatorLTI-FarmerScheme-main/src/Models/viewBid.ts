export class ViewBid
{
    BCID?:number;
    BID?:number;
    UserId?:number;
    CropID?:number;
    MSP?:number;
    CurrentBid?:number;
    FinalBid?:number;

}