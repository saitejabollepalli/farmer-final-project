export class Doc{
    DocId?:number;
    Docfile?:File;
}