export class forgotpass
{
    email?:string;
}