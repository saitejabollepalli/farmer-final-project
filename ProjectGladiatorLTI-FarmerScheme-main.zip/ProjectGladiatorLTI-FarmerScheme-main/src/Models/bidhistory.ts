export class Marketplace
{
    UserID?:number;
    currentBid ?:number;
    baseprice?:number;
    cropid  ?:number;
    cropname?:string;
    croptype?:string;
    bidstatus?:string;

}