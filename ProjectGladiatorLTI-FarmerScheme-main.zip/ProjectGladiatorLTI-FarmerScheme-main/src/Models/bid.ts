export class Bid{
    cropName?:string;
    bidAmount?:number;
    dateOfBid?:Date;
}