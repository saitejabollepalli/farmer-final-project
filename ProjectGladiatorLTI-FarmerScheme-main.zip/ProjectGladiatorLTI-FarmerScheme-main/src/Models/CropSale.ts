export class CropSale
{
    Croptype?:number;
    CropName?:string;
    BasePrice?:number;
    CurrentBid?:number;

}