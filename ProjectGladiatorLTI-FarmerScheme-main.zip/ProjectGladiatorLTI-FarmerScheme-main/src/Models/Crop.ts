export class Crop{
          cropId?:number ;
          userId?:number ;
          cropType?:string ;
          cropName?:string ;
          quantity?:number ;
          Quantity?:number;
          soilPh?:number ;
          dateOfSoldCrop?:Date ;
          msp?:number;
          MSP?:number;
          soldPrice?:number ;
          totalPrice?:number ;
          statusOfCropSell?:string ; 
          statusofCropsell?:string;
          soilCert?:string;
          fertilizerType?:string;
          FertilizerType?:string;
        //   /////////////////////
        
    //SoilPh?:number;
            dateofSoldCrop?:Date;
            
            finalbidamount?:number;
        
            baseMSp?:number;
            bidstatus?:string;
            cropid?:number;
            croptype?:string;
            cropname?:string;
            basemsp?:number;
            BaseMSp?:number;
}