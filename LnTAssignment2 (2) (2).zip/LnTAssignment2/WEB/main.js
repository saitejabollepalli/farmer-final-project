// JavaScript source code
function ValidateEmail(input) {
    var validRegex = /@./;
    if (input.value.match(validRegex)) {
        alert("Valid email address!");
        document.form1.text1.focus();
        return true;
    } else {
        alert("Invalid email address!");
        document.form1.text1.focus();
        return false;

    }

}