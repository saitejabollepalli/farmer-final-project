import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BidderwelcomeComponent } from './Bidderwelcome/bidderwelcome/bidderwelcome.component';

const routes: Routes = [
  {
    path:"bidder",
    component:BidderwelcomeComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
