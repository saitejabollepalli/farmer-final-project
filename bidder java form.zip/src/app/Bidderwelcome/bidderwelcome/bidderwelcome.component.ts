import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators} from '@angular/forms';
@Component({
  selector: 'app-bidderwelcome',
  templateUrl: './bidderwelcome.component.html',
  styleUrls: ['./bidderwelcome.component.css']
})
export class BidderwelcomeComponent implements OnInit {
  Bidderform: FormGroup=new FormGroup({
    Bidamt:new FormControl('',Validators.required)
  })

  constructor() { }

  ngOnInit(): void {
  }
  submit():void{
    console.log(`Details Added`);
    this.Bidderform.reset();

}

}
