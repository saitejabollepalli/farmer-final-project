﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FarmerScheme.Models
{
    public class BidderLoginModel
    {
        public string username { get; set; }
        public string password { get; set; }
    }
}
