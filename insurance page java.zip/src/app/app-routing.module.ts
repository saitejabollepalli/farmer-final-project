import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ClaimFormComponent } from './FarmerProject/claim-form/claim-form.component';
import { InsuranceApplicationFormComponent } from './FarmerProject/insurance-application-form/insurance-application-form.component';


const routes: Routes = [
  {
    path:"ApplyForm",component:InsuranceApplicationFormComponent
  },
  {
    path:"ClaimForm",component:ClaimFormComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
