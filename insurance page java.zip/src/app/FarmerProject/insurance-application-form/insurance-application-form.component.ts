import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators} from '@angular/forms';
@Component({
  selector: 'app-insurance-application-form',
  templateUrl: './insurance-application-form.component.html',
  styleUrls: ['./insurance-application-form.component.css']
})
export class InsuranceApplicationFormComponent implements OnInit {
  applyfrom: FormGroup=new FormGroup({
    season:new FormControl('',Validators.required),
    year:new FormControl('',Validators.required),
    si:new FormControl('',Validators.required),
    crop:new FormControl('',Validators.required),
    area:new FormControl('',Validators.required)
    
  })
  constructor() { }

  ngOnInit(): void {
  }

}
