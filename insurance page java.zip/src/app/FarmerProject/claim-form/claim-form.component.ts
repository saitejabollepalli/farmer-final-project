import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators} from '@angular/forms';

@Component({
  selector: 'app-claim-form',
  templateUrl: './claim-form.component.html',
  styleUrls: ['./claim-form.component.css']
})
export class ClaimFormComponent implements OnInit {
  claimfrom: FormGroup=new FormGroup({
    policyno:new FormControl('',Validators.required),
    inc:new FormControl('',Validators.required),
    noi:new FormControl('',Validators.required),
    si:new FormControl('',Validators.required),
    col:new FormControl('',Validators.required),
    dol:new FormControl('',Validators.required)
  })
  constructor() { 
   }
  
  ngOnInit(): void {
    
  }
  
  submit():void{
    console.log("claim-form");
    
  }

}
